console.log(
  "PROJECT ID:",
  process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID
);

console.log(
  "API KEY EXISTS:",
  !!process.env.NEXT_PUBLIC_FIREBASE_API_KEY
);

import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey:
    process.env.NEXT_PUBLIC_FIREBASE_API_KEY,

  authDomain:
    process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,

  projectId:
    process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,

  storageBucket:
    process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,

  messagingSenderId:
    process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,

  appId:
    process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

export const app =
  initializeApp(
    firebaseConfig
  );

export const db =
  getFirestore(
    app
  );